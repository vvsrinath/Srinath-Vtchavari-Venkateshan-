import React from 'react';

const Skills = () => {
  return (
    <section id="skills" className="min-h-screen p-8 bg-white">
      <h2 className="text-3xl font-bold mb-4">Skills</h2>
      <ul className="list-disc list-inside">
        <li>HTML, CSS, JavaScript</li>
        <li>Python</li>
        <li>Fusion 360, AutoCAD</li>
        <li>Renewable Energy Research</li>
      </ul>
    </section>
  );
};

export default Skills;
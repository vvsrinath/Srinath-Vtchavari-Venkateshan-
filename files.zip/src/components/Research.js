import React from 'react';

const Research = () => {
  return (
    <section id="research" className="min-h-screen p-8 bg-gray-100">
      <h2 className="text-3xl font-bold mb-4">Research</h2>
      <div>
        <h3 className="text-2xl font-bold">Vertical Wind Turbine Research</h3>
        <p>Details about the research.</p>
      </div>
    </section>
  );
};

export default Research;
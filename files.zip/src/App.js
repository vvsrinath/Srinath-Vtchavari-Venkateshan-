import React from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Projects from './components/Projects';
import Research from './components/Research';
import Skills from './components/Skills';
import Blog from './components/Blog';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Home />
      <Projects />
      <Research />
      <Skills />
      <Blog />
      <Footer />
    </div>
  );
}

export default App;